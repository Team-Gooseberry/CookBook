﻿
namespace CookBook.Common
{
    public class GlobalConstants
    {
        public const string EmptyString = "";
    }
}
