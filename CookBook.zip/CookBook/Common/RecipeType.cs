﻿
namespace CookBook.Common
{
    public enum RecipeType
    {
        Salad,
        Soup,
        WarmStarter, 
        ColdStarter,
        Main,
        Dessert
    }
}
