﻿namespace CookBook
{
    class Startup
    {
        public static void Main()
        {
            CookBookEngine.Start();
            
        }
    }
}
