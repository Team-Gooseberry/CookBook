﻿
namespace CookBook.Contracts
{
    public interface INamed
    {
        string Name { get; set; }
    }
}
