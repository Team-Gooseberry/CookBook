# **Team Gooseberry**
## C# OOP Teamwork

### Team members

- Desislav Dimov - *dimov165*
- Krum Popov - *KrumecaHg*
- Pavel Yankov - *pavel_yankov*
- Petar Bochukov - *Aimanan*
- Petar Yerzhabek - *Xenoleth*
- Stefan Dantchev - *hankrum*
- Yassen Trayanov - *Yask00*

**Github repository: https://github.com/Team-Gooseberry/CookBook**

## **COOK BOOK PROGRAMM**

The program is an electronic cook book.
This is a set of recipes for cooking. Each recipe is a list of necessary products with their quantities and a list of actions for the preparation of the meal. The program can search in the recipe database by recipe name, product name, recipe type (soup, salad, dessert, etc.), recipe price and preparation time.
The recipes are recorded in an XML file.

![Class diagram](ClassDiagram1.jpg)
